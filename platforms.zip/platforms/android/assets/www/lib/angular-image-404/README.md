[DEMO of angular-image-404](http://stiekel.github.io/angular-image-404/)
