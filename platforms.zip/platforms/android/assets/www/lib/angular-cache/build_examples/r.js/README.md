Running `r.js -o require.config.js` in this directory will produce `bundle.js`

In `index.html` switch `script/main` between `main` (load scripts dynamically) and `bundle` (load bundled scripts)
