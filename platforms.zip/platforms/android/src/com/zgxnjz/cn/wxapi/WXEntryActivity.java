package com.zgxnjz.cn.wxapi;

public class WXEntryActivity extends EntryActivity {
}
