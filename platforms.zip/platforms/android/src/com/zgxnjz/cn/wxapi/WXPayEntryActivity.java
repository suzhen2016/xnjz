package com.zgxnjz.cn.wxapi;

public class WXPayEntryActivity extends EntryActivity {

}
